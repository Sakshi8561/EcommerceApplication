package com.handloomstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandloomstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
