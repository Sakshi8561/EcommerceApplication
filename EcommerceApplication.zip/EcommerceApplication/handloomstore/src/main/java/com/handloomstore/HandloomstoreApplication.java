package com.handloomstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandloomstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandloomstoreApplication.class, args);
		System.out.println("Application is running");
	}

}
